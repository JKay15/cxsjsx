#ifndef OBJECTS_H
#define OBJECTS_H
#pragma once

#include "game.h"
#include "tags.h"
#include "helpers.h"
#include "behaviours.h"
#include "actions.h"
#include "sprites.h"
#include "fx.h"

namespace objects
{
    QSharedPointer<game::GameObject>  Corpse();        // 尸体
    QSharedPointer<game::GameObject>  BleedSpell();    // 流血效果
    QSharedPointer<game::GameObject>  Skeleton();      // 骷髅
    QSharedPointer<game::GameObject>  SkeletonLord();  // 大骷髅
    QSharedPointer<game::GameObject>  Villager();      // 村民
    QSharedPointer<game::GameObject>  Bandit();        // 歹徒
    QSharedPointer<game::GameObject>  TheKing();       // 国王
    QSharedPointer<game::GameObject>  Champion();      // 冠军
    QSharedPointer<game::GameObject>  ShellKnight();   // 盔甲骑士
    QSharedPointer<game::GameObject>  Monk();          // 和尚
    QSharedPointer<game::GameObject>  Archer();        // 弓箭手
    QSharedPointer<game::GameObject>  Piper();         // 演奏家
    QSharedPointer<game::GameObject>  Rat();           // 老鼠
    QSharedPointer<game::GameObject>  RageKnight();    // 狂怒骑士
    QSharedPointer<game::GameObject>  RoyalGuard();    // 皇家卫士
    QSharedPointer<game::GameObject>  RoyalGuardOrb(); // 皇家卫士的装备
    QSharedPointer<game::GameObject>  Wizard();        // 巫师
    QSharedPointer<game::GameObject>  Portal();        // 传送门
}

#endif // OBJECTS_H
