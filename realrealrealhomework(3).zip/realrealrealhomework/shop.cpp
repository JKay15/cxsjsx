// shop.cpp
#include "shop.h"

// 初始化商店变量
Shop shop = {
    {},
    {},
    0};

// 购买函数实现
void buy()
{
    game::ShopItem item = shop.items[shop.selectedIndex];
    if (item.cost <= game::game.souls)
    {
        game::game.souls -= item.cost;
        helpers::removeFromArray(shop.items, item);
        item.purchase();
        selectShopIndex(shop.selectedIndex);
    }
}

// 选择商店物品索引函数实现
void selectShopIndex(int step)
{
    shop.selectedIndex = helpers::clamp(shop.selectedIndex + step, 0, shop.items.size() - 1);
}

// 进入商店函数实现
void enterShop()
{
    game::game.state = game::SHOPPING;
    restockShop();
    game::game.onShopEnter();
    // useShopSynths();
}

// 退出商店函数实现
void exitShop()
{
    game::game.state = game::PLAYING;
    nextLevel();
    // useLevelSynths();
}

// 重新进货函数实现
void restockShop()
{
    int exp = pow(game::game.level + 1, 2);
    QVector<game::ShopItem> items = {
        {10 * game::game.level, "Heal", "Heal 1*", []()
         { actions::Damage(game::game.player, -1); }},
        {10 * exp, "Renew", "+1* max hp", []()
         {
             game::game.player->maxHp++;
             game::game.player->hp++;
         }},
        {10 * exp, "Recharge", "+1\x7F max casts", []()
         { game::game.spell.maxCasts++; }}};

    // 获取 ritualItems
    QVector<game::ShopItem> ritualItems = createRitualItems();

    // 将 ritualItems 添加到 items 中
    for (const auto& item : ritualItems) {
        items.append(item);
    }

    // 添加最后一个元素
    items.push_back({0, "Continue", "Begin the next level", []()
                     { exitShop(); }});

    shop.items = items;
}

// 创建仪式物品列表函数实现
QVector<game::ShopItem> createRitualItems()
{
    QVector<game::Ritual> rituals = helpers::shuffled(shop.rituals);
    rituals.erase(std::remove_if(rituals.begin(), rituals.end(), [](const game::Ritual &ritual) { return !game::game.canAddRitual(ritual); }), rituals.end());

    QVector<game::Ritual> commons;
    for (const auto& ritual : rituals) {
        if (ritual.rarity != game::RARE) {
            commons.push_back(ritual);
        }
    }

    QVector<game::Ritual> rares;
    for (const auto& ritual : rituals) {
        if (ritual.rarity == game::RARE) {
            rares.push_back(ritual);
        }
    }

    QVector<game::Ritual> pool;
    if (!rares.empty()) {
        pool.push_back(rares.front());
    }
    if (commons.size() >= 2) {
        pool.push_back(commons[0]);
        pool.push_back(commons[1]);
    }

    QVector<game::ShopItem> result;

    for (game::Ritual &ritual : pool)
    {
        result.push_back({ritual.rarity == game::RARE ? 200 + helpers::randomInt(100) : 75 + helpers::randomInt(100),
                          ritual.name,
                          ritual.description,
                          [&ritual]() mutable { // 添加 mutable 关键字来消除错误
                              helpers::removeFromArray(shop.rituals, ritual);
                              game::game.addRitual(ritual); // 传递指针而非对象本身
                          }});
    }

    return result;
}
