#ifndef LEVELS_H
#define LEVELS_H
#pragma once

#include "tags.h"
#include "objects.h"
#include "helpers.h"
#include "game.h"
#include <unordered_map>
// 信号常量
const int END_OF_LEVEL = 99;
const int END_OF_WAVE = 98;
// 敌人的ID
const int VILLAGER = 0;
const int ARCHER = 1;
const int MONK = 2;
const int CHAMPION = 3;
const int PIPER = 4;
const int RAGE_KNIGHT = 5;
const int ROYAL_GUARD = 6;
const int SHELL_KNIGHT = 7;
const int WIZARD = 8;
const int THE_KING = 9;
const int RAT = 10;
const int MOB = 11;
const int BANDIT = 12;
// 敌人的别称
using Spawn = std::function<QSharedPointer<game::GameObject>()>;
// 储存敌人的容器
extern QVector<Spawn> LOOKUP;
extern std::unordered_map<std::variant<std::string, int>, std::function<int()>> DELAYS;
extern QVector<int> LEVELS;
// 是否消灭了所有敌人
bool isCleared();
// 是否完成任务
bool isComplete();
// 是否完成了这一关
bool isLevelFinished();
// 关卡升级
void updateLevel(double dt);
// 下一关
void nextLevel();

#endif // LEVELS_H
