// behaviours.cpp
#include "behaviours.h"

int behaviours::screenShakeTimer = 0; // 定义一个整型变量 screenShakeTimer，其初始值为 0
void behaviours::screenshake(QPainter &painter, double time)
{                                        // 定义 Renderer 类的 screenshake 方法，该方法接受一个 QPainter 对象和一个 double 类型变量作为参数
    behaviours::screenShakeTimer = time; // 将 screenShakeTimer 的值设为 time
}

std::map<int, behaviours::SpellCounter> behaviours::HitStreak::counters;

// 法术对象函数实现
QSharedPointer<game::GameObject> behaviours::Spell()
{
    QSharedPointer<game::GameObject> object = QSharedPointer<game::GameObject>::create(); // 创建游戏对象
    object->sprite = sprites::p_green_skull;                 // 设置精灵图像
    object->tags = SPELL;                                    // 设置标签
    object->collisionMask = MOBILE | LIVING;                 // 设置碰撞掩码
    object->mass = 100;                                      // 设置质量
    object->emitter = fx::trail();                           // 设置特效发射器
    object->friction = 0.1;                                  // 设置摩擦力
    object->despawnOnCollision = true;                       // 碰撞后消失标记设置为真
    object->despawnOnBounce = true;                          // 弹跳后消失标记设置为真
    object->addBehaviour(new behaviours::Damaging(object)); // 添加造成伤害行为
    return object;                                          // 返回游戏对象
}

// 闪电法术对象函数实现
QSharedPointer<game::GameObject> behaviours::LightningSpell()
{
    QSharedPointer<game::GameObject> spell = behaviours::Spell(); // 创建法术对象
    spell->sprite = sprites::p_skull_yellow;       // 设置精灵图像
    spell->emitter->frequency = 0.8;                // 设置特效发射器发射频率
    spell->emitter->variants = {                    // 设置特效发射器精灵图像变体列表
                              {sprites::p_lightning_1, sprites::p_lightning_2, sprites::p_lightning_3, sprites::p_lightning_4},
                              {sprites::p_lightning_1, sprites::p_lightning_2, sprites::p_lightning_3, sprites::p_lightning_5},
                              {sprites::p_lightning_2, sprites::p_lightning_3, sprites::p_lightning_6},
                              {sprites::p_lightning_4, sprites::p_lightning_5, sprites::p_lightning_6},
                              {sprites::p_purple_5}};
    return spell; // 返回游戏对象
}
