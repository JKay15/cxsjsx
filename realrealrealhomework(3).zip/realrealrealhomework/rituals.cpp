#include "rituals.h"

game::Ritual Streak{
    NONE,
    "Streak",
    "",
    [](QSharedPointer<game::GameObject> spell)
    {
        spell->addBehaviour(new behaviours::HitStreak(spell));
    }};

game::Ritual Bouncing{
    BOUNCING,
    "Bouncing",
    "Spells bounce",
    [](QSharedPointer<game::GameObject> spell)
    {
        spell->addBehaviour(new behaviours::DespawnTimer(spell, 3000));
    }};

game::Ritual Doubleshot{
    SPLITTING,
    SPLITTING,
    game::RARE,
    "Doubleshot",
    "Cast 2 spells",
    []()
    {
        game::game.spell.shotsPerRound = 2;
    }};

game::Ritual Hunter{
    HOMING,
    game::RARE,
    "Hunter",
    "Spells seek targets",
    [](QSharedPointer<game::GameObject>  projectile)
    {
        projectile->addBehaviour(new behaviours::Seeking(projectile));
    }};

game::Ritual Weightless{
    NONE,
    "Weightless",
    "Spells are not affected by gravity",
    [](QSharedPointer<game::GameObject>  spell)
    {
        spell->mass = 0;
        spell->friction = 0;
        spell->bounce = 1;
    }};

game::Ritual Knockback{
    NONE,
    "Knockback",
    "Spells knock backwards",
    [](QSharedPointer<game::GameObject> spell)
    {
        spell->addBehaviour(new KnockbackSpell(spell));
    }};
game::Ritual Ceiling{
    NONE,
    BOUNCING,
    "Ceiling",
    "Adds a ceiling",
    []()
    {
        game::game.stage.ceiling = 48;
    }};

game::Ritual Rain{
    SPLITTING,
    SPLITTING,
    game::RARE,
    "Rain",
    "Spells split when they drop",
    false,
    [](QSharedPointer<game::GameObject>  spell)
    {
        spell->addBehaviour(new RainSpell(spell));
    }};

game::Ritual Drunkard{
    NONE,
    "Drunkard",
    "2x damage, wobbly aim",
    [](QSharedPointer<game::GameObject> spell)
    {
        spell->vx += helpers::randomInt(100) - 50;
        spell->vy += helpers::randomInt(100) - 50;
        std::optional<behaviours::Damaging *> behaviourPtr = spell->getBehaviour<behaviours::Damaging>();
        if (behaviourPtr)
        {
            behaviours::Damaging *Damageptr = *behaviourPtr;
            Damageptr->amount *= 2;
        }
    }};

game::Ritual Seer{
    NONE,
    "Seer",
    "Spells pass through the dead",
    [](QSharedPointer<game::GameObject> spell)
    {
        spell->collisionMask = LIVING;
    }};

game::Ritual Tearstone{
    NONE,
    "Tearstone",
    "2x damage when < half HP",
    [](QSharedPointer<game::GameObject> spell)
    {
        if (game::game.player->hp < game::game.player->maxHp / 2)
        {
            std::optional<behaviours::Damaging *> behaviourPtr = spell->getBehaviour<behaviours::Damaging>();
            if (behaviourPtr)
            {
                behaviours::Damaging *Damageptr = *behaviourPtr;
                Damageptr->amount *= 3;
            }
        }
    }};

game::Ritual Impatience{
    NONE,
    "Impatience",
    "Resurrection recharges 2x faster",
    []()
    {
        game::game.ability.cooldown /= 2;
    }};

game::Ritual Bleed{
    CURSE,
    "Bleed",
    "Inflicts bleed on hits",
    [](QSharedPointer<game::GameObject> spell)
    {
        spell->sprite = sprites::p_red_skull;
        spell->emitter->extend({{sprites::p_red_3, sprites::p_red_2, sprites::p_red_1},
                               {sprites::p_red_4, sprites::p_red_3, sprites::p_red_2},
                               {sprites::p_red_3, sprites::p_red_2, sprites::p_red_1}},
                              5,
                              {helpers::DEG_180, 0},
                              {20, 50});
        game::Behaviour *inflict = spell->addBehaviour();
        inflict->onCollision = [&](QSharedPointer<game::GameObject> target)
        {
            target->addBehaviour(new behaviours::Bleeding(target));
        };
    }};

game::Ritual Allegiance{
    NONE,
    "Allegiance",
    "Summon your honour guard after resurrections",
    []()
    {
        for (int i = 0; i < 3; i++)
        {
            QSharedPointer<game::GameObject>  unit = objects::SkeletonLord();
            unit->updateSpeed = 200;
            game::game.spawn(unit, i * -15, 0);
        }
    }};

game::Ritual Salvage{
    NONE,
    "Salvage",
    "Corpses become souls at the end of levels",
    []()
    {
        QVector<QSharedPointer<game::GameObject> > corpses;
        for (auto object : game::game.objects)
        {
            if (object->is(CORPSE))
            {
                corpses.push_back(object);
            }
        }
        for (QSharedPointer<game::GameObject>  corpse : corpses)
        {
            QSharedPointer<ParticleEmitter>  emitter = fx::bones();
            emitter->extend(
                        corpse->center().x,
                        corpse->center().y,
                {{sprites::p_green_skull}},
                {100, 1000});
            emitter->burst(5);
            emitter->remove();
            game::game.spawn(corpse);
            game::game.addSouls(5);
        }
    }};

game::Ritual Studious{
    NONE,
    game::RARE,
    "Studious",
    "Rituals are 50% cheaper",
    []()
    {
        for (auto item : shop.items)
        {
            item.cost = static_cast<int>(item.cost / 2);
        }
    }};
game::Ritual Electrodynamics{
    NONE,
    game::RARE,
    "Electrodynamics",
    "Lightning strikes after hits",
    [](QSharedPointer<game::GameObject> spell) {

    }};

game::Ritual Chilly{
    NONE,
    "Chilly",
    "10% chance to freeze enemies",
    [](QSharedPointer<game::GameObject> spell)
    {
        if (helpers::randomFloat() < 0.1)
        {
            spell->emitter->variants = {{sprites::p_ice_1, sprites::p_ice_2, sprites::p_ice_3}};
            spell->sprite = sprites::p_skull;
            std::optional<behaviours::Damaging *> behaviourPtr = spell->getBehaviour<behaviours::Damaging>();
            if (behaviourPtr)
            {
                behaviours::Damaging *Damageptr = *behaviourPtr;
                Damageptr->amount = 0;
            }
            spell->addBehaviour()->onCollision = [&](QSharedPointer<game::GameObject> target)
            {
                if (target->mass < 1000)
                {
                    target->addBehaviour(new behaviours::Frozen(target), 0);
                }
            };
        }
    }};

game::Ritual Giants{
    NONE,
    "Giants",
    "20% chance to resurrect giant skeletons",
    [](QSharedPointer<game::GameObject> Object1)
    {
        if (helpers::randomFloat() < 0.2)
        {
            game::game.despawn(Object1);
            game::game.spawn(objects::SkeletonLord(), Object1->x, Object1->y);
        }
    }};

game::Ritual Hardened{
    NONE,
    "Hardened",
    "Undead have +1 HP*",
    [](QSharedPointer<game::GameObject> object)
    {
        object->hp = object->maxHp += 1;
    }};
