#ifndef HELPERS_H
#define HELPERS_H
#pragma once

#include <cmath>
#include <vector>
#include <QVector>

namespace helpers
{
    // 一些角度常量
    const double DEG_180 = M_PI;
    const double DEG_90 = DEG_180 / 2;
    const double DEG_270 = DEG_180 + DEG_90;
    const double DEG_360 = DEG_180 * 2;

    // 点的结构体
    struct Point
    {
        double x;
        double y;
        Point(double xx = 0, double yy = 0) : x(xx), y(yy) {}
    };

    // 向量的别名
    typedef QVector<double> Vector;

    // 创建一个点
    Point createPoint(double x, double y);

    // 长方形的类
    struct Rectangle
    {
        double x;
        double y;
        double w;
        double h;
        Rectangle(int _x = 0, int _y = 0, int _w = 0, int _h = 0) : x(_x), y(_y), w(_w), h(_h) {}
    };

    // 创建一个矩形
    Rectangle createRectangle(double x, double y, double w, double h);

    // 判断两个矩形是否重叠
    bool overlaps(Rectangle a, Rectangle b);

    // 将值限制在给定的范围内
    double clamp(double val, double min, double max);

    // 根据给定的角度，创建一个向量
    Vector vectorFromAngle(double radians);

    // 计算两个点之间的夹角
    double angleBetweenPoints(Point p1, Point p2);

    // 从数组中删除指定的元素
    template <typename T>
    void removeFromArray(QVector<T> &array, const T &element)
    {
        typename QVector<T>::iterator it = std::find(array.begin(), array.end(), element);
        if (it != array.end())
        {
            array.erase(it);
        }
    }

    // 从数组中随机选择一个元素
    template <typename T>
    T randomElement(QVector<T> &items)
    {
        int index = rand() % items.size();
        return items[index];
    }

    // 计算两个点之间的距离
    double distance(Point p1, Point p2);

    // 根据给定的 X 和 Y 值，计算向量的角度
    double vectorToAngle(double x, double y);

    // 生成一个指定范围内的随机整数
    int randomInt(int max);

    // 生成一个指定范围内的随机浮点数
    double randomFloat(double max = 1);

    // 线程休眠指定时间
    void sleep(int ms);

    // 将数组中的元素随机排序
    template <typename T>
    QVector<T> shuffled(QVector<T> array){
        int m = array.size();

        while (m)
        {
            int i = helpers::randomInt(m--);
            std::swap(array[m], array[i]);
        }

        return array;
    }
}
#endif /* HELPERS_H */
