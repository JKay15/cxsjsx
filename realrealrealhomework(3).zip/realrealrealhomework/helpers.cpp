#include "helpers.h"
#include <algorithm>
#include <chrono>
#include <thread>

// 创建一个点
helpers::Point helpers::createPoint(double x, double y)
{
    helpers::Point p;
    p.x = x;
    p.y = y;
    return p;
}

// 创建一个矩形
helpers::Rectangle helpers::createRectangle(double x, double y, double w, double h)
{
    helpers::Rectangle r;
    r.x = x;
    r.y = y;
    r.w = w;
    r.h = h;
    return r;
}

// 判断两个矩形是否重叠
bool helpers::overlaps(helpers::Rectangle a, helpers::Rectangle b)
{
    return (a.x < b.x + b.w && a.y < b.y + b.h &&
            a.x + a.w > b.x && a.y + a.h > b.y);
}

// 将值限制在给定的范围内
double helpers::clamp(double val, double min, double max)
{
    return val < min ? min : val > max ? max
                                       : val;
}

// 根据给定的角度，创建一个向量
helpers::Vector helpers::vectorFromAngle(double radians)
{
    helpers::Vector v;
    v.push_back(cos(radians));
    v.push_back(sin(radians));
    return v;
}

// 计算两个点之间的夹角
double helpers::angleBetweenPoints(helpers::Point p1, helpers::Point p2)
{
    return atan2(p2.y - p1.y, p2.x - p1.x);
}

// 计算两个点之间的距离
double helpers::distance(helpers::Point p1, helpers::Point p2)
{
    return hypot(p2.x - p1.x, p2.y - p1.y);
}

// 根据给定的 X 和 Y 值，计算向量的角度
double helpers::vectorToAngle(double x, double y)
{
    return atan2(y, x);
}

// 生成一个指定范围内的随机整数
int helpers::randomInt(int max)
{
    return rand() % max;
}

// 生成一个指定范围内的随机浮点数
double helpers::randomFloat(double max)
{
    return static_cast<double>(rand()) / RAND_MAX * max;
}

// 线程休眠指定时间
void helpers::sleep(int ms)
{
    std::this_thread::sleep_for(std::chrono::milliseconds(ms));
}
