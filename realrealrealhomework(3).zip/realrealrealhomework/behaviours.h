#ifndef BEHAVIOURS_H
#define BEHAVIOURS_H
#pragma once

#include <string>
#include "game.h"
#include "helpers.h"
#include "tags.h"
#include "sprites.h"
#include "engine.h"
#include "actions.h"
#include "sprites.h"
#include "fx.h"

namespace behaviours
{
    // 屏幕抖动计时器
    extern int screenShakeTimer;

    // 屏幕抖动函数
    void screenshake(QPainter &painter, double time);

    // 施法函数
    QSharedPointer<game::GameObject>  Spell();

    // 雷电法术施法函数
    QSharedPointer<game::GameObject>  LightningSpell();

    // 结构体：法术计数器
    struct SpellCounter
    {
        int total; // 总数
        int hits;  // 命中数
    };

    // 攻击行为类
    class Attack : public game::Behaviour
    {
    public:
        //这里的object只能是GameObject *，不能是QSharedPointer<game::GameObject>
        Attack( QSharedPointer<game::GameObject> object) : Behaviour(object)
        {
            onCollision = [&](QSharedPointer<game::GameObject> target) { // 使用引用捕获方式
                int dealDamage = object->hp;
                int takeDamage = target->hp;
                actions::Damage(target, dealDamage, object);
                actions::Damage(object, takeDamage, target);
            };
        }
    };

    // 消失计时器行为类
    class DespawnTimer : public game::Behaviour
    {
    public:
        int elapsed = 0; // 已经过去的时间
        int duration;    // 持续时间
        // 构造函数
        // 帧更新函数
         //这里的object只能是GameObject *，不能是QSharedPointer<game::GameObject>
        DespawnTimer(QSharedPointer<game::GameObject> object, const int duration) : Behaviour(object), duration(duration)
        {
            onFrame = [&](double dt)
            {
                if ((elapsed += dt) >= duration)
                {
                    game::game.despawn(this->object);
                }
            };
        }
    };

    // 行军行为类
    class March : public game::Behaviour
    {
    public:
//        int step=0; // 步长
        std::function<std::optional<bool>(QPainter &painter)> onUpdate=[](QPainter &painter)->std::optional<bool>{return std::optional<bool>();};
         //这里的object只能是GameObject *，不能是QSharedPointer<game::GameObject>
        March(QSharedPointer<game::GameObject> object, int step1) : Behaviour(object)
        {
            step=step1;
            onUpdate = [&](QPainter &painter)
            {
                if (this->object->y > 0)
                    return std::optional<bool>();

                tween(this->object->x, this->object->x + step, 200, [&](double x, double t)
                      {
                this->object->x = x;
                this->object->hop = std::sin(t * M_PI) * 2;
                if (t == 1 && this->object->mass >= 100) screenshake(painter,50); });

                if ((step < 0 && this->object->x < 0) || (step > 0 && this->object->x > game::game.stage.width))
                {
                    game::game.despawn(this->object);
                }

                return std::optional<bool>();
            };
        }; // 构造函数
        // 更新函数
    };

    // 造成伤害行为类
    class Damaging : public game::Behaviour
    {
    public:
        int amount = 1; // 伤害量 // 碰撞处理函数
         //这里的object只能是GameObject *，不能是QSharedPointer<game::GameObject>
        Damaging(QSharedPointer<game::GameObject> object) : Behaviour(object)
        {
            onCollision = [&](QSharedPointer<game::GameObject >target)
            {
                actions::Damage(target, this->amount, this->object);
            };
        }
    };

    // 流血行为类
    class Bleeding : public game::Behaviour
    {
    public:
        QVector<int> sprite = sprites::status_bleeding; // 精灵图像
        int turns = 3;                                      // 持续回合数
        int amount = 1;                                     // 伤害量
        QSharedPointer<ParticleEmitter> emitter=nullptr;
        //这里的object只能是GameObject *，不能是QSharedPointer<game::GameObject>
        Bleeding(QSharedPointer<game::GameObject> ob) : Behaviour(ob)
        {
            emitter = fx::cloud({0, 0, 0, 0}, {{sprites::health_orb, sprites::health_pip}, {sprites::health_pip}});
            emitter->extend(0, {}, {10, 30}, {10, 30});

            onUpdate = [&]()-> std::optional<bool>
            {
                    emitter->extend(object->center().x, object->center().y);
                    if (emitter!=nullptr) {
                        emitter->burst(1);
                    }
                    actions::Damage(object, 1, object);
                    return std::optional<bool>();
            };
        }
    };

    // 愤怒行为类
    class Enraged : public game::Behaviour
    {
    public:
        QVector<int> sprite = sprites::status_enraged; // 精灵图像
        int mask; // 掩码
        QSharedPointer<ParticleEmitter> emitter=nullptr;

        Enraged(QSharedPointer<game::GameObject> object, int mask) : Behaviour(object), mask(mask)
        {
            emitter = fx::cloud({0, 0, 0, 0}, {{sprites::health_orb, sprites::health_pip}, {sprites::health_pip}});
            emitter->extend(0, {}, {10, 30}, {10, 30});
            onDamage = [&](struct game::Damage *damage)
            {
                if (damage->dealer && damage->dealer->is(this->mask))
                {
                    actions::Damage(this->object, -damage->amount, this->object);
                    damage->amount = 0;
                    this->emitter->extend(this->object->bounds());
                    this->emitter->burst(4);
                }
            };
        } // 构造函数
          // 受到伤害处理函数
    };

    // 寻找行为类
    class Seeking : public game::Behaviour
    {
    public:
        std::function<void()> onFrame=[](){};
        Seeking(QSharedPointer<game::GameObject> ob) : Behaviour(ob)
        {
            onFrame = [&]()
            {
                QSharedPointer<game::GameObject >projectile = object;
                QSharedPointer<game::GameObject >target = nullptr;
                double minDist = 100;

                for (QSharedPointer<game::GameObject>obj : game::game.objects)
                {
                    if (obj->is(object->collisionMask))
                    {
                        double dist = distance(projectile->center(), obj->center());
                        if (dist < minDist)
                        {
                            target = obj;
                            minDist = dist;
                        }
                    }
                }

                if (target)
                {
                    double currentAngle = helpers::vectorToAngle(projectile->vx, projectile->vy);
                    double desiredAngle = helpers::angleBetweenPoints(projectile->center(), target->center());
                    double angle = currentAngle + (desiredAngle - currentAngle) / 20;
                    double magnitude = std::hypot(projectile->vx, projectile->vy);
                    double vx, vy;
                    auto res = helpers::vectorFromAngle(angle);
                    vx = res[0];
                    vy = res[1];
                    projectile->vx = vx * magnitude;
                    projectile->vy = vy * magnitude;
                }
            };
        }
    };

    // 召唤行为类
    class Summon : public game::Behaviour
    {
    private:
        int summonTimer = 0; // 召唤计时器
    public:
        int summonCounter = 0; // 召唤计数器

        std::function<QSharedPointer<game::GameObject> ()> create=[]()->QSharedPointer<game::GameObject>{return QSharedPointer<game::GameObject>();}; // 创建对象函数
        int summonSpeed;                          // 召唤速度
        std::function<void(QSharedPointer<game::GameObject>)> onSummon=[](QSharedPointer<game::GameObject>){return QSharedPointer<game::GameObject>();};
        void defaultOnSummon(QSharedPointer<game::GameObject>ob)
        {
            // 默认的 onSummon 行为
        }
        Summon(QSharedPointer<game::GameObject> object, std::function<QSharedPointer<game::GameObject> ()> create, int summonSpeed) : Behaviour(object), create(create), summonSpeed(summonSpeed)
        {
            // 将默认函数绑定到 onSummon
            onSummon = std::bind(&Summon::defaultOnSummon, this, std::placeholders::_1);
            onFrame = [&](double dt)
            {
                if ((this->summonTimer += dt) > this->summonSpeed)
                {
                    summonTimer = 0;
                    summonCounter++;
                    QSharedPointer<game::GameObject>  ob = this->create();
                    game::game.spawn(ob, this->object->x, this->object->y);
                    this->onSummon(ob);
                }
            };
        } // 构造函数
        void changeOnSummon(std::function<void()> newOnSummon)
        {
            onSummon = std::bind([](std::function<void()> func, QSharedPointer<game::GameObject>ob)
                                 { func(); },
                                 newOnSummon, std::placeholders::_1);
        }
    };

    // 连击行为类

    class HitStreak : public game::Behaviour
    {
    public:
        static std::map<int, SpellCounter> counters; // 计数器映射表
        bool hit = false;                            // 是否命中标记
        SpellCounter counter;                        // 计数器
        std::function<void()> onCollision = [&]()
        {
            this->hit = true;
        };
        HitStreak(QSharedPointer<game::GameObject> ob) : Behaviour(ob)
        {
            onAdded = [=]()
            {
                counter = HitStreak::counters[object->groupId];
                counter.total++;
            };
            onRemoved = [=]()
            {
                if (hit)
                    counter.hits++;
                if (--counter.total)
                    return;
                if (counter.hits)
                {
                    game::game.streak = helpers::clamp(game::game.streak + 1, 0, game::MAX_STREAK);
                }
                else
                {
                    game::game.streak = 0;
                }
            };
        }
    };

    // 无敌行为类
    class Invulnerable : public game::Behaviour
    {
    public:
        QVector<int> sprite = sprites::status_shielded; // 精灵图像

        Invulnerable(QSharedPointer<game::GameObject> ob) : Behaviour(ob)
        {
            onDamage = [&](struct game::Damage *damage)
            {
                if (damage->amount > 0)
                    damage->amount = 0;
            };
        }
    };

    // 冰冻行为类
    class Frozen : public game::Behaviour
    {
    public:
        int freezeTimer = 10; // 冰冻计时器

        Frozen(QSharedPointer<game::GameObject> ob) : Behaviour(ob)
        {
            onUpdate = [&]()
            {
                if (freezeTimer-- <= 0)
                {
                    object->removeBehaviour(this);
                }
                return true;
            };
        }
    };

    // 闪电打击行为类
    class LightningStrike : public game::Behaviour
    {
    public:
        LightningStrike(QSharedPointer<game::GameObject> ob) : Behaviour(ob)
        {
            onCollision = [&](QSharedPointer<game::GameObject>target)
            {
                int bolts = 3;
                for (int i = 0; i < bolts; i++)
                {
                    auto bolt = behaviours::LightningSpell();
                    bolt->vy = -200;
                    bolt->vx = helpers::randomInt(20) - 10;
                    bolt->y = helpers::clamp(50 + helpers::randomInt(100), 0, game::game.stage.ceiling - 10);
                    bolt->x = target->x + helpers::randomInt(50) - 25;
                    game::game.spawn(bolt);
                }
            };
        }
    };
}

#endif // BEHAVIOURS_H
