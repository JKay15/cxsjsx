#include "game.h"

game::ShopItem game::createShopItem(int cost, const std::string &name, const std::string &description, void (*purchase)())
{
    ShopItem item;
    item.cost = cost;
    item.name = name;
    item.description = description;
    item.purchase = purchase;
    return item;
}

// 骨头特效函数实现
QSharedPointer<ParticleEmitter> fx::bones()
{
    ParticleEmitter* emitter = new ParticleEmitter(
        {10000, 5000},                                                  // 持续时间范围
        {0.6, 0},                                                       // 摩擦力范围
        {5, 20},                                                        // 初速度范围
        {helpers::DEG_90 - 0.5, 1},                                     // 角度范围
        {0.1, 0.5},                                                     // 弹性范围
        {60, 0},                                                        // 质量范围
        {{sprites::p_bone_1}, {sprites::p_bone_2}, {sprites::p_bone_3}} // 精灵图像变体列表
    );
    return QSharedPointer<ParticleEmitter>(emitter);
}

// 轨迹特效函数实现
QSharedPointer<ParticleEmitter> fx::trail()
{
    ParticleEmitter* emitter = new ParticleEmitter({
        {500, 1000},  // 持续时间范围
        {0.5, 0},     // 摩擦力范围
        {1, 10},      // 初速度范围
        {M_PI, -0.5}, // 角度范围
        {0, 0},       // 弹性范围
        {3, 0},       // 质量范围
        {{sprites::p_green_1, sprites::p_green_2, sprites::p_green_3},
         {sprites::p_green_2, sprites::p_green_3, sprites::p_green_4},
         {sprites::p_green_1, sprites::p_green_2, sprites::p_green_3}}, // 精灵图像变体列表
        2                                                               // 发射频率
    });
    return QSharedPointer<ParticleEmitter>(emitter);
}

// 云特效函数实现
QSharedPointer<ParticleEmitter> fx::cloud(const helpers::Rectangle& area, const QVector<QVector<Sprite>>& variants)
{
    ParticleEmitter* emitter  = new ParticleEmitter(
        {
            {500, 1000},                  // 持续时间范围
            {1, 10},                      // 初速度范围
            {helpers::DEG_90 - 0.2, 0.4}, // 角度范围
            {0, 0},                       // 弹性范围
            variants,                     // 精灵图像变体列表
            2,                            // 发射频率
            area.x,
            area.y,
            area.w,
            area.h,
            {-2, 0} // 质量范围
        }
    );
    // 转换为 QSharedPointer 并返回
    return QSharedPointer<ParticleEmitter>(emitter);
}

// 皇室特效函数实现
QSharedPointer<ParticleEmitter> fx::royalty()
{
    QSharedPointer<ParticleEmitter> emitter  = trail();
    emitter->extend(
        0.5, // 发射频率
        {{sprites::p_star_1, sprites::p_star_2, sprites::p_star_3},
         {sprites::p_star_2, sprites::p_star_3, sprites::p_star_4},
         {sprites::p_star_1, sprites::p_star_3}} // 精灵图像变体列表
    );
    return emitter;
}

// 复活特效函数实现
QSharedPointer<ParticleEmitter> fx::resurrect(QSharedPointer<game::GameObject> unit)
{
    QSharedPointer<ParticleEmitter> emitter  = (
        cloud(unit->bounds(), {{sprites::p_green_1, sprites::p_green_2, sprites::p_green_3},
                              {sprites::p_green_2, sprites::p_green_3, sprites::p_green_4},
                              {sprites::p_green_1, sprites::p_green_3, sprites::p_green_5}})

    );
    emitter->extend(0);
    return QSharedPointer<ParticleEmitter>(emitter);
}
// 玩家对象函数实现
QSharedPointer<game::GameObject> game::Player()
{
    QSharedPointer<game::GameObject> player(new game::GameObject);  // 创建游戏对象并用 QSharedPointer 管理其生命周期
    player->x = 5;                                                  // 设置初始位置
    player->tags = PLAYER | UNDEAD;                                  // 设置标签
    player->sprite = sprites::norman_arms_down;                      // 设置精灵图像
    player->collisionMask = LIVING;                                  // 设置碰撞掩码
    player->updateSpeed = 1000;                                      // 设置更新速度
    player->hp = player->maxHp = 5;                                   // 设置生命值和最大生命值
    player->emitter = fx::resurrect(player);                         // 设置特效发射器
    return player;                                                   // 返回游戏对象
}
// 重要的全局变量（但是位置很偏）！！！！！！
//game::GameObject game::player = game::Player();
//game::Game game::game = game::Game(game::player);

// 灰尘特效函数实现——依赖game，所以写后面了
QSharedPointer<ParticleEmitter> fx::dust()
{
    return QSharedPointer<ParticleEmitter>(new ParticleEmitter({
        {5000, 10000},                        // 持续时间范围
        {1, 3},                               // 初速度范围
        {helpers::DEG_360, helpers::DEG_360}, // 角度范围
        {0, 0},                               // 弹性范围
        {{sprites::p_dust_1, sprites::p_dust_2},
         {sprites::p_dust_2, sprites::p_dust_1, sprites::p_dust_3, sprites::p_dust_1}}, // 精灵图像变体列表
        0.1,                                                                            // 发射频率
        0,
        0,
        game::game.stage.width,
        game::game.stage.height,
    }));
}

// Game的一堆需要依赖game的成员函数
void game::Game::onLevelStart()
{
    for (auto ritual : game.rituals)
    {
        if(ritual.onLevelStart)
            ritual.onLevelStart();
    }
}
void game::Game::onLevelEnd()
{
    for (auto ritual : game.rituals)
    {
        if(ritual.onLevelEnd)
            ritual.onLevelEnd();
    }
}
void game::Game::onShopEnter()
{
    for (auto ritual : game.rituals)
    {
        if(ritual.onShopEnter)
            ritual.onShopEnter();
    }
}
void game::Game::onCast(QSharedPointer<GameObject> spell, bool recursive)
{
    for (auto ritual : game.rituals)
    {
        if (recursive && ritual.recursive == false)
        {
            continue;
        }
        if(ritual.onCast)
            ritual.onCast(spell);
    }
}
void game::Game::updateAbility(int dt)
{
    game.ability.timer += dt;
    game.player->emitter->frequency = game.ability.timer >= game.ability.cooldown ? 0.1 : 0;
}

// GameObject需要依赖game的成员函数
void game::GameObject::onCollision(QSharedPointer<GameObject> target)
{
    QSharedPointer<GameObject> self(this, [](GameObject* obj) { /* do nothing */ });
    if ((tags & PLAYER) == 0)
    {
        for (auto& behaviour : behaviours)
        {
            behaviour->onCollision(std::move(target));
        }
        if (despawnOnCollision)
        {
            game.despawn(self);
        }
    }
    else
    {
    }
}
