#ifndef RENDERER_H
#define RENDERER_H
#pragma once

// renderer.h
#include <QPainter>
#include "sprites.h"
#include "engine.h"
#include "helpers.h"
#include "game.h"
#include "shop.h"
#include "behaviours.h"
#include "objects.h"
namespace renderer
{
    void screenshake(QPainter &painter, double time); // 屏幕抖动函数
    helpers::Point screenToSceneCoords(QPainter &painter, double x, double y);
    void render(QPainter &painter, double dt);
    void drawShop(QPainter &painter);
    void drawHud(QPainter &painter);
    void drawOrbs(QPainter &painter,double x, double y, double value, double maxValue, const Sprite &sprite, const Sprite &emptySprite);
    void drawObjects(QPainter &painter);
    void drawBackground(QPainter &painter);
    void drawReticle(QPainter &painter);
    void drawParticles(QPainter &painter);

}

#endif // RENDERER_H
