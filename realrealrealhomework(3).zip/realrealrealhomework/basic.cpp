#include "basic.h"

const double G = 10;

// Pos 类的实现
basic::Pos::Pos(double a, double b) : posx(a), posy(b) {}

basic::Pos basic::calcAngleSin(basic::Pos p1, basic::Pos p2)
{
    double dx = p2.posx - p1.posx;
    double dy = p2.posy - p1.posy;
    double dist = std::sqrt(dx * dx + dy * dy);
    if (dist == 0)
    {
        return basic::Pos(0, 0); // 如果两个点重合，返回 0
    }

    double sinVal = dy / dist; // 计算 sin 值
    double cosVal = dx / dist;
    basic::Pos ans(sinVal, cosVal);
    return ans;
}

// Bullet 类的实现
basic::Bullet::Bullet(double x, double y, double sp, double a, double ax, double ay)
    : posx(x), posy(y), speed(sp), angle_x(ax), angle_y(ay), atk(a) {}

void basic::Bullet::move(int time)
{
    posx += speed * angle_x * time;
    posy -= (0.5 * G * time * time + speed * angle_y * time);
}

// Player 类的实现
basic::Player::Player(int h, double x, double y) : hp(h), posx(x), posy(y), bullets(nullptr) {}

void basic::Player::move(double k)
{
    posx += k;
}

void basic::Player::shoot(basic::Pos mouse)
{
    basic::Pos angle = basic::calcAngleSin(basic::Pos(posx, posy), mouse);
    bullets = new basic::Bullet(posx, posy, 1, 10, angle.posx, angle.posy);
}

basic::Pos basic::Player::angle(basic::Pos mouse)
{
    basic::Pos temp(posx, posy);
    return basic::calcAngleSin(temp, mouse);
}

void basic::Player::die()
{
    // 游戏结束
}

// Enemy 类的实现
basic::Enemy::Enemy(int h, double x, double y, double a, double s, double rx, double ry)
    : hp(h), posx(x), posy(y), atk(a), speed(s), range_x(rx), range_y(ry) {}

void basic::Enemy::move(double k)
{
    posx += k * speed;
}

void basic::Enemy::die()
{
}

bool basic::_outofrange(basic::Pos pos, double range_x = 600, double range_y = 400)
{
    if (pos.posx < 0 || pos.posx > range_x || pos.posy < 0 || pos.posy > range_y)
    {
        return true;
    }
    return false;
}

void basic::attack(basic::Enemy *enemy, basic::Bullet *bullet)
{
    if (bullet->posx < enemy->posx + enemy->range_x && bullet->posx > enemy->posx - enemy->range_x && bullet->posy < enemy->posy + enemy->range_y && bullet->posy > enemy->posy - enemy->range_y)
    {
        enemy->hp -= bullet->atk;
        if (enemy->hp <= 0)
        {
            enemy->die();
        }
        delete bullet;
    }
    else if (_outofrange(basic::Pos(bullet->posx, bullet->posy), 600, 400))
    {
        delete bullet;
    }
}

void basic::attack(basic::Player *player, basic::Enemy *Enemy)
{
    player->hp -= Enemy->atk;
    if (player->hp <= 0)
        player->die();
}
