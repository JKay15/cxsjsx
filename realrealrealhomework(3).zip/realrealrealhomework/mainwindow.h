#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QImage>
#include <QPainter>
#include "fx.h"
#include <vector>
#include <string>
#include "sprites.h"
#include "engine.h"
#include "game.h"
#include "renderer.h"
#include "actions.h"
#include "helpers.h"
#include "objects.h"
#include "levels.h"
#include "rituals.h"
#include "shop.h"

// #include "sounds.h"
#include "behaviours.h"
const int ARROW_UP = 38;
const int ARROW_DOWN = 40;
const int SPACE = 32;
const int ENTER = 13;
const int KEY_P = 80;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

namespace Mainwindow
{
    void update(QPainter &painter, double dt);
}
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
public slots:
    void onpointerup();
    void onpointermove(QPainter &painter, int clientX, int clientY);
    void onkeydown(int key);

protected:
    void mouseReleaseEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void keyPressEvent(QKeyEvent *event) override;

private:
    void paintEvent(QPaintEvent *event) override;
    void drawCanvas();

    Ui::MainWindow *ui;
    QImage canvas;
    QPainter* painter;
    bool paused = false;
    qint64 t0; // 添加t0变量来保存时间戳

    // 添加成员变量来记录是否需要画圆和需要打印的文本
    bool m_drawCircle;
    QString m_text;
};

#endif // MAINWINDOW_H
