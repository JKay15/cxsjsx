#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QTimer>
#include <QDateTime>
#include "engine.h"
#include"game.h"
#include <QMouseEvent>


bool paused = false;

QVector<std::string> INTRO_DIALOGUE = {
    "Norman wasn't a particularly popular necromancer...",
    "         The other villagers hunted him.",
    "     Sometimes they even finished the job (@)",
    "  But like any self-respecting necromancer...",
    "        Norman just brought himself back.",
};

QVector<std::string> OUTRO_DIALOGUE = {
    "",
    "It was over.",
    "Norman was able to study peacefully.",
    "But he knew that eventually, they'd be back.",
    "THE END",
};
// 当游戏胜利时的函数
void onWin()
{
    // 设置游戏状态为胜利，并显示结束对话框
    game::game.state = game::WIN;
    game::game.dialogue = OUTRO_DIALOGUE;
}
double dialogueTimer = 0;

// 更新对话框的函数，参数是时间间隔（毫秒）
void updateDialogue(double dt)
{

    // 如果对话框计时器超过4秒，就移除第一句对话，并重置计时器
    if ((dialogueTimer += dt) > 0.4)
    {
        game::game.dialogue.erase(game::game.dialogue.begin());
        dialogueTimer = 0;

        // 如果玩家观看了整个介绍对话框，就提醒他们点击开始游戏
        if (game::game.state == game::INTRO && game::game.dialogue.size() == 0)
        {
            game::game.dialogue.push_back("                (Click to begin)");
        }
    }
}

//game::GameObject game::player = game::Player();
//game::Game game::game = game::Game(game::player);
bool normanIsBouncing = false;


void Mainwindow::update(QPainter &painter, double dt)
{
    // 更新对话框和渲染画面
    updateDialogue(dt);
    renderer::render(painter, dt);

    // 如果游戏暂停，就不进行后续的更新
    if (paused)
        return;
    // 如果游戏处于进行状态，就更新关卡逻辑
    if (game::game.state == game::PLAYING)
    {
        updateLevel(dt);
    }

    // 如果游戏不是处于介绍状态，就更新游戏对象和法术逻辑
    if (game::game.state != game::INTRO)
    {
        game::game.update(dt);
    }

    // 更新缓动动画和粒子效果
    updateTweens(dt);
    updateParticles(dt);
    // 如果游戏处于进行状态并且关卡完成，就判断是否整个游戏胜利，或者进入商店
    if (game::game.state == game::PLAYING && isLevelFinished())
    {
        if (isComplete())
        {
            onWin();
        }
        else
        {
            game::game.onLevelEnd();
            enterShop();
        }
    }

    // 如果游戏进入第二关，并且玩家还没有弹跳的行为，就给玩家添加一个弹跳的行为
    if (game::game.level == 2 && !normanIsBouncing)
    {
        game::game.player->addBehaviour(new behaviours::March((game::game.player), 0));
        game::game.player->updateClock = 100;
        game::game.player->updateSpeed = 60000 / 240 * 2;   //BPM在sound里
        normanIsBouncing = true;
    }
}


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    t0 = QDateTime::currentMSecsSinceEpoch(); // 初始化t0为当前时间戳

    QTimer* timer = new QTimer(this);
    connect(timer, &QTimer::timeout, [this]() {
        qint64 t1 = QDateTime::currentMSecsSinceEpoch();
        double dt = (t1 - t0) / 1000.0;
        t0 = t1;
        update(); // 触发重绘
    });
    // 给游戏添加一个连击仪式
    game::game.addRitual(Streak);

    // 设置商店的可选仪式列表
    shop.rituals = {
        Bouncing,
        Ceiling,
        Rain,
        Doubleshot,
        Hunter,
        Weightless,
        Knockback,
        Drunkard,
        Seer,
        Tearstone,
        Impatience,
        Bleed,
        Salvage,
        Studious,
        Electrodynamics,
        Chilly,
        Giants,
        // Avarice,
        Hardened,
        Allegiance,
    };

    // 设置游戏的初始对话框为介绍对话框
    game::game.dialogue = INTRO_DIALOGUE;

    timer->start(16);
    //fx::dust().burst(200);
}

void MainWindow::onpointerup()
{

    // 如果游戏处于介绍状态，就开始游戏，并改变玩家的精灵
    if (game::game.state == game::INTRO)
    {

        // play();播放声音
        game::game.state = game::PLAYING;

        game::game.player->sprite = sprites::norman_arms_down;

    }

    // 发射法术
    actions::Cast();

    // 在鼠标点击的位置画圆
    m_drawCircle = true;
     update();
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event)
{
    // 调用基类的实现
    QMainWindow::mouseReleaseEvent(event);

    // 在此处处理鼠标释放事件
    onpointerup();
}

void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    // 调用基类的实现
    QMainWindow::mouseMoveEvent(event);

    // 获取 QPainter 对象
    QPainter painter(this);

    // 获取鼠标位置
    int clientX = event->position().x();
    int clientY = event->position().y();

    // 调用 onpointermove 函数
    onpointermove(painter, clientX, clientY);
}

void MainWindow::onpointermove(QPainter &painter, int clientX, int clientY)
{
    // 计算玩家和鼠标位置之间的角度，并设置法术的目标角度
    //auto p1 = game::player.center();
    //auto p2 = renderer::screenToSceneCoords(painter, clientX, clientY);
    //game::game.spell.targetAngle = angleBetweenPoints(p1, p2);

    // 将光标变成十字准星
    QApplication::setOverrideCursor(Qt::CrossCursor);
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    // 调用基类的实现
    QMainWindow::keyPressEvent(event);

    // 获取按键代码
    int key = event->key();

    // 调用 onkeydown 函数
    onkeydown(key);
}

void MainWindow::onkeydown(int key)
{
    // 如果游戏处于进行状态，根据按键执行不同的操作
    if (game::game.state == game::PLAYING)
    {
        // 如果按下空格键，就复活一个敌人作为盟友
        if (key == Qt::Key_Space)
            actions::Resurrect();
        // 如果按下P键，就暂停或恢复游戏
        if (key == Qt::Key_P)
            paused = !paused;
    }
    else if (game::game.state == game::SHOPPING)
    {
        // 如果游戏处于商店状态，根据按键选择或购买仪式
        if (key == Qt::Key_Up)
            selectShopIndex(-1);
        if (key == Qt::Key_Down)
            selectShopIndex(+1);
        if (key == Qt::Key_Enter)
            buy();
    }

    // 在光标位置打印字母
    m_text = QKeySequence(key).toString();
    update();
}

void MainWindow::paintEvent(QPaintEvent *event) {
    Q_UNUSED(event);
    QPainter painter(this); // 创建QPainter对象，指定绘图设备为窗口
    qint64 t1 = QDateTime::currentMSecsSinceEpoch();
    double dt = (t1 - t0) / 1000.0;
    Mainwindow::update(painter, dt);

    // 在鼠标点击的位置画圆
    if (m_drawCircle) {
        painter.setBrush(Qt::black);
        painter.drawEllipse(mapFromGlobal(QCursor::pos()), 10, 10);
        m_drawCircle = false;
    }

    // 在光标位置打印字母
    if (!m_text.isEmpty()) {
        painter.drawText(mapFromGlobal(QCursor::pos()), m_text);
        m_text.clear();
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

