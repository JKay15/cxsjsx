// engine.h
#ifndef ENGINE_H
#define ENGINE_H
#pragma once

#include <set>
#include <utility>
#include <QPixmap>
#include "helpers.h"
#include <vector>
#include <unordered_map>
#include <string>
#include <QRect>
#include <QLabel>
#include <QJsonObject>
#include <QMainWindow>

// 精灵的别名，方便调用
using Sprite = QVector<int>;
// 从png图片中截取人物部分的像素
extern QPixmap *spriteSrc;
// 从png图片中截取人物部分的图像
extern QImage spritesImage;
// 字体宽度
extern int glyphWidth;
// 字体高度
extern int glyphHeight;
// 线的高度
extern int lineHeight;
// 导入字体json
extern QJsonObject glyphWidthOverrides;
// 字体存储
extern std::unordered_map<char, int> metrics;

// 导入字体
void import_font();

// 长方形的类，用来表示角色在png图像中的位置
class Rect
{
public:
    double x;
    double y;
    double w;
    double h;

    Rect(double x, double y, double w, double h)
        : x(x), y(y), w(w), h(h) {}
};

// 画布
extern QImage canvas;
// 清除画布
void clear();
// 绘制角色
void drawSprite(QPainter &painter,const Sprite &sprite, int x, int y);
// 倒过来绘制角色
void drawSceneSprite(QPainter &painter,const Sprite &sprite, int x, int y);
// 绘制角色的一部分
void drawSpriteSlice(QPainter &painter,int sx, int sy, int sw, int sh, int dx, int dy, int dw, int dh);
// 通过切分角色为九部分实现缩放
void drawNineSlice(QPainter &painter,const Sprite &sprite, int x, int y, int w, int h);

// 文本坐标
extern int textX;
extern int textY;
// 绘制文本
void write(const std::string &text, int x = textX, int y = textY);

// 改变大小
void resize();

// 初始化画布
void init(QPainter &painter, int width, int height, void (*update)(QPainter &painter, double));

// 缓动函数
using Easing = std::function<double(double)>;

// 动画参数
struct Tween
{
    double startValue;
    double endValue;
    double duration;
    double elapsed;
    Easing ease;
    std::function<void(double, double)> callback=[](double,double){};
};

// 动画存储容器
extern QVector<Tween> tweens;
// 线性函数
extern double linear(double x);
// 更新动画
extern void updateTweens(double dt);
// 动画播放
extern void tween(double startValue, double endValue, double duration, std::function<void(double, double)> callback, Easing ease = linear);

// 范围结构体
using Range = std::pair<double, double>;
// 定义默认范围
extern const Range defaultRange;
// 产生随即范围函数
extern double randomFromRange(const Range &range);

// 粒子发射器
class ParticleEmitter;
// 储存粒子发射器的容器

// 粒子的类
struct Particle
{
    double x;
    double y;
    double vx;
    double vy;
    double bounce;
    double elapsed;
    double duration;
    int variant;
    double mass;
    double friction;
    bool operator<(const Particle &other) const
    {
        return this < &other; // 使用对象的地址比较
    }

};

// 粒子发射器
class ParticleEmitter
{
private:
    static QVector<Particle> pool;

public:
    std::set<Particle> particles;
    static QVector<QSharedPointer<ParticleEmitter>> particleEmitters;
    double x = 0;
    double y = 0;
    double w = 0;
    double h = 0;

    QVector<QVector<Sprite>> variants = {};
    double frequency = 0;
    Range velocity = defaultRange;
    Range angle = defaultRange;
    Range duration = defaultRange;
    Range bounce = defaultRange;
    Range friction = defaultRange;
    Range mass = defaultRange;

    double clock = 0;
    bool done = false;

    ParticleEmitter()
    {
        QSharedPointer<ParticleEmitter> sharedThis(new ParticleEmitter);
        particleEmitters.push_back(sharedThis);
    }
    ParticleEmitter(Range Duration, Range Friction, Range Velocity, Range Angle, Range Bounce, Range Mass, QVector<QVector<Sprite>> Variant, double Frequency = 0, double X = 0, double Y = 0, double W = 0, double H = 0)
    {
        duration = Duration;
        friction = Friction;
        velocity = Velocity;
        angle = Angle;
        bounce = Bounce;
        mass = Mass;
        variants = Variant;
        frequency = Frequency;
        x = X;
        y = Y;
        w = W;
        h = H;
        QSharedPointer<ParticleEmitter> sharedThis(this, [](ParticleEmitter* p) { delete p; });
        particleEmitters.push_back(sharedThis);
    }
    ParticleEmitter(Range Duration, Range Velocity, Range Angle, Range Bounce, QVector<QVector<Sprite>> Variant, double Frequency, double X, double Y, double W, double H, Range Mass = defaultRange, Range Friction = defaultRange)
    {
        duration = Duration;
        friction = Friction;
        velocity = Velocity;
        angle = Angle;
        bounce = Bounce;
        mass = Mass;
        variants = Variant;
        frequency = Frequency;
        x = X;
        y = Y;
        w = W;
        h = H;
        QSharedPointer<ParticleEmitter> sharedThis(this, [](ParticleEmitter* p) { delete p; });
        particleEmitters.push_back(sharedThis);
    }

    ParticleEmitter(const ParticleEmitter &other) = default;
    ParticleEmitter &operator=(const ParticleEmitter &other) = default;

    bool operator==(const ParticleEmitter& other) const
    {
        return x == other.x &&
               y == other.y &&
               w == other.w &&
               h == other.h &&
               variants == other.variants &&
               frequency == other.frequency;
    }


    ParticleEmitter(ParticleEmitter &&other) noexcept = default;
    ParticleEmitter &operator=(ParticleEmitter &&other) noexcept = default;

    void extend(double Frequency, QVector<QVector<Sprite>> Variant = {}, Range Mass = defaultRange, Range Velocity = defaultRange);
    void extend(double X, double Y);
    void extend(helpers::Rectangle rec);
    void extend(QVector<QVector<Sprite>> Variant);
    void extend(QVector<QVector<Sprite>> Variant, double Frequency, Range Angle, Range Mass);
    void extend(double X, double Y, QVector<QVector<Sprite>> Variant, Range Duration);
    void remove();

    void update(double dt);

    void Emit();

    QSharedPointer<ParticleEmitter> burst(int count);
};
// 更新粒子发射器
extern void updateParticles(double dt);

#endif // ENGINE_H
