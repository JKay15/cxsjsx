#include "mainwindow.h"
#include <QApplication>
#include <QLabel>
#include <QScreen>
QSharedPointer<game::GameObject> game::player = game::Player();
game::Game game::game = game::Game(game::player);
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // 创建窗口
    MainWindow w;
    // 显示窗口
    w.show();

    return a.exec();
}
