#ifndef BASIC_H
#define BASIC_H
#pragma once

#include <iostream>
#include <cstring>
#include <cmath>

namespace basic
{
    // 位置
    class Pos
    {
    public:
        double posx, posy;
        Pos(double a, double b);
    };
    // 计算正弦函数
    Pos calcAngleSin(Pos p1, Pos p2);
    // 子弹
    class Bullet
    {
    public:
        double posx, posy;
        double speed;
        double angle_x, angle_y;
        double atk;
        Bullet *next;
        // 添加构造函数
        Bullet(double x, double y, double sp, double a, double ax = 0, double ay = 0);

        void move(int time);
    };
    // 玩家
    class Player
    {
    public:
        int hp;
        double posx, posy;
        Bullet *bullets; // 存放子弹

        // 添加构造函数
        Player(int h, double x, double y);

        void move(double k);

        void shoot(Pos mouse);

        Pos angle(Pos mouse);

        void die();
    };
    // 敌人
    class Enemy
    {
    public:
        int hp;
        double posx, posy;
        double atk;
        double speed;
        double range_x, range_y; // 子弹击中判定范围

        // 添加构造函数
        Enemy(int h, double x, double y, double a, double s, double rx, double ry);

        void move(double k);

        void die();
    };
    // 超范围
    bool _outofrange(Pos bullet, double x, double y);
    // 玩家攻击敌人
    void attack(Enemy *enemy, Bullet *bullet);
    // 敌人攻击玩家
    void attack(Player *player, Enemy *Enemy);
}

#endif // BASIC_H
