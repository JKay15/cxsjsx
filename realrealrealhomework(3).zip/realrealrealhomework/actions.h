#ifndef ACTIONS_H
#define ACTIONS_H
#pragma once

#include <string>
#include "game.h"
#include "helpers.h"
#include "tags.h"
#include <chrono>
#include <thread>
#include "sprites.h"
#include "fx.h"

namespace actions
{
    // 造成伤害函数
    void Damage(QSharedPointer<game::GameObject> object, int amount, QSharedPointer<game::GameObject> dealer = nullptr);
    // 死亡函数
    void Die(QSharedPointer<game::GameObject> object, QSharedPointer<game::GameObject> killer = nullptr);
    // 施法函数
    void Cast();
    // 复活函数
    void Resurrect();
}

#endif // ACTIONS_H
