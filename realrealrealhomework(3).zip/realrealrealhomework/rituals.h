#ifndef RITUALS_H
#define RITUALS_H
#pragma once

#include "behaviours.h"
#include "game.h"
#include "sprites.h"
#include "engine.h"
#include "helpers.h"
#include "objects.h"
#include "tags.h"
#include "shop.h"
#include "fx.h"
#include <random>

// 技能特性的掩码
const int NONE = 0;
const int BOUNCING = 1 << 0;
const int SPLITTING = 1 << 1;
const int EXPLOSIVE = 1 << 2;
const int HOMING = 1 << 3;
const int WARDSTONES = 1 << 4;
const int CASTING_RATE = 1 << 5;
const int CURSE = 1 << 6;

// 技能的函数（一部分）
extern game::Ritual Streak;
extern game::Ritual Bouncing;
extern game::Ritual Doubleshot;
extern game::Ritual Hunter;
extern game::Ritual Weightless;

// 击退法术的类
class KnockbackSpell : public game::Behaviour
{
public:
    KnockbackSpell(QSharedPointer<game::GameObject> ob) : Behaviour(ob)
    {
        onCollision = [=](QSharedPointer<game::GameObject>target)
        {
            if (target->mass < 1000)
            {
                tween(target->x, target->x + 16, 200, [=](double v, double t)
                      { target->x = v * t; });
            }
        };
    }
};

// 击退技能（依赖击退法术类）
extern game::Ritual Knockback;
// 产生一个天花板的技能
extern game::Ritual Ceiling;

// 法术分裂为多个的类
class RainSpell : public game::Behaviour
{
public:
    bool split = false;
    std::function<void()> onFrame=[](){};
    RainSpell(QSharedPointer<game::GameObject> ob) : Behaviour(ob)
    {
        onFrame = [=]()
        {
            if (!split && object->vy < 0)
            {
                split = true;
                QSharedPointer<game::GameObject>p0 = object;
                QSharedPointer<game::GameObject> p1 = behaviours::Spell();
                QSharedPointer<game::GameObject> p2 = behaviours::Spell();
                p1->x = p2->x = p0->x;
                p1->y = p2->y = p0->y;
                p1->vx = p2->vx = p0->vx;
                p1->vy = p2->vy = p0->vy;
                p1->vx -= 20;
                p2->vx += 20;
                p1->groupId = p2->groupId = p0->groupId;
                game::game.onCast(p1, true);
                game::game.onCast(p2, true);
                game::game.spawn(p1);
                game::game.spawn(p2);
            }
        };
    }
};

// 其他技能
extern game::Ritual Rain;            // 法术分裂为三个
extern game::Ritual Drunkard;        // 醉拳
extern game::Ritual Seer;            // 穿透（尸体）法术
extern game::Ritual Tearstone;       // 破釜沉舟（血量小于一半，攻击力翻倍）
extern game::Ritual Impatience;      // 降低召唤死灵的技能冷却时间
extern game::Ritual Bleed;           // 流血技能
extern game::Ritual Allegiance;      // 在复活之后集结死灵
extern game::Ritual Salvage;         // 尸体在游戏结束时换钱
extern game::Ritual Studious;        // 商店物品便宜一半
extern game::Ritual Electrodynamics; // 闪电法术
extern game::Ritual Chilly;          // 寒冰法术
extern game::Ritual Giants;          // 有机会召唤出巨人死灵
extern game::Ritual Hardened;        // 死灵的血量加1

#endif // RITUALS_H
